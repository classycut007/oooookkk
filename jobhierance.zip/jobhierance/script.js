const slider = document.querySelector('.home-slider');
slider.innerHTML += slider.innerHTML; // Duplicate the slider content



// job - companie section js -----------------------------------------------------------------------------------

const cardsContainer = document.querySelector(".companies-job-cards");
const leftButton = document.querySelector(".left-btn");
const rightButton = document.querySelector(".right-btn");

let currentIndex = 0; // Start at the first group of cards
const cardsPerView = 3; // Show 3 cards at a time
const cardWidth = 320; // The width of each card (including margin)

leftButton.addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;
    updateCarousel();
  }
});

rightButton.addEventListener("click", () => {
  const totalCards = cardsContainer.children.length;
  const maxIndex = Math.floor(totalCards / cardsPerView) - 1;
  if (currentIndex < maxIndex) {
    currentIndex++;
    updateCarousel();
  }
});

function updateCarousel() {
  // Move the carousel by the width of 3 cards
  cardsContainer.style.transform = `translateX(-${currentIndex * cardWidth * cardsPerView}px)`;
}



// companie section js -----------------------------------------------------------------------------------

 // Apply the background images dynamically to each slide
 document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".slide");

  slides.forEach(slide => {
      const background = slide.getAttribute("data-background");
      if (background) {
          slide.style.backgroundImage = `url('${background}')`;
      }
  });

  const slider = document.querySelector(".slider");
  const slideWidth = slides[0].clientWidth;
  let currentSlide = 1;

  // Position the slider to start from the first actual slide
  slider.style.transform = `translateX(-${slideWidth * currentSlide}px)`;

  function showNextSlide() {
      currentSlide++;
      slider.style.transition = "transform 0.5s ease-in-out";
      slider.style.transform = `translateX(-${slideWidth * currentSlide}px)`;

      // Reset to the first slide smoothly after the last cloned slide
      slider.addEventListener("transitionend", () => {
          if (currentSlide === slides.length - 1) {
              slider.style.transition = "none"; // Disable transition
              currentSlide = 0; // Reset to the first slide
              slider.style.transform = `translateX(-${slideWidth * currentSlide}px)`;
          }
      });
  }

  setInterval(showNextSlide, 3000); // Change slide every 3 seconds
});